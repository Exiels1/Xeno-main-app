
Xeno — Personal AI Starter App
------------------------------------
This is a starter Flask-based Xeno app that stores chat history per username and provides
a simple AI-response placeholder. It is cross-platform friendly: run the backend on a PC or VPS,
and use the web frontend on any device (phone or PC).

Quick start:
  1. python3 -m venv venv
  2. source venv/bin/activate    # or venv\Scripts\activate on Windows
  3. pip install -r requirements.txt
  4. export OPENAI_API_KEY=your_key  # optional, for better AI responses
  5. python app.py
  6. Open http://localhost:8080 and create a username

Notes:
  - This is a starter template. Extend with socket.io, authentication, encryption for production.
  - For Android packaging consider using a WebView wrapper, PWA, or host backend and create native clients.
#   x e n o _ a p p  
 